const ps = require("photoshop");
const { core, action } = require("photoshop");
const app = ps.app;
const modal = ps.core.executeAsModal;
const constants = ps.constants;
const SolidColor = require("photoshop").app.SolidColor;
const storage = window.require("uxp").storage;
let anchor = ps.constants.AnchorPosition;

const label_doc_name = document.getElementById("doc_name");
const label_doc_size = document.getElementById("doc_size");
const label_doc_dpi = document.getElementById("doc_dpi");
const label_doc_layers = document.getElementById("doc_layers");

const body_main = document.getElementById("body_main");
const layerlist = document.getElementById("layerlist");
const scan_btn = document.getElementById("scan_btn");
const export_json_btn = document.getElementById("export_json_btn");
const clear_btn = document.getElementById("clear_btn");
const typeselector_global = document.getElementById("typeselector_global");

const fs = require("fs");
const os = require("os");

let AllLayers = [];
let layerdatas = [];
let groupdatas = [];

//#region 界面控件主逻辑

/* 获取文档图层信息
 */
scan_btn.addEventListener("click", async () => {
  ClearItems();
  GetAllLayers();
  GetDocumentInfo();

  //#region  如果文档有效显示导出Json按钮
  if (AllLayers.length <= 0) {
    ClearDocumentInfo();
    export_json_btn.style.display = "none";
    clear_btn.style.display = "none";
    return;
  } else {
    export_json_btn.style.display = "inline-flex";
    clear_btn.style.display = "inline-flex";
  }
  //#endregion

  core.executeAsModal(async () => {
    for (let i = 0; i < AllLayers.length; i++) {
      await AddListitem(AllLayers[i]);
    }
  });
});

/* 导出文档图层信息为Json数据
 */
export_json_btn.addEventListener("click", () => {
  let size = `${app.activeDocument.width}, ${app.activeDocument.height}`;

  const outputDir = String(app.activeDocument.path).replace(
    app.activeDocument.name,
    ""
  );
  let path_psd = outputDir;
  let path_sprites = path_psd + "Sprites";

  let mode = getFormattedDocMode(app.activeDocument.mode);

  let cur_times = getFormattedTime();
  let cur_dates = getFormattedDate();
  let datetime = { date: cur_dates, time: cur_times };

  let count_la = 0;
  let count_gp = 0;
  for (let i = 0; i < AllLayers.length; i++) {
    if (AllLayers[i].kind == "group") {
      count_gp += 1;
    } else {
      count_la += 1;
    }
  }

  // console.log(count_gp);
  // console.log(count_la);

  let structure = {
    name: label_doc_name.innerText + ".psd",
    colormode: mode,
    datetime: datetime,
    size: size,
    dpi: app.activeDocument.resolution,
    path_psd: path_psd,
    path_sprites: path_sprites,
    count_layer: count_la,
    count_group: count_gp,
    layers: layerdatas,
    groups: groupdatas,
  };

  let dat_root = { structure };

  ExportJson(dat_root);
});

/* 清空文档图层信息
 */
clear_btn.addEventListener("click", async () => {
  ClearItems();
  ClearDocumentInfo();

  export_json_btn.style.display = "none";
  clear_btn.style.display = "none";

  await openDialog_status(
    "重置完成！已清空所有收集的图层数据和文档信息！",
    "明白"
  );
  await window.location.reload(1);
});

//#endregion

//#region 辅助类

/* 获取系统信息
 */
function GetSystemInfo() {
  let infos = {
    platform: os.platform(),
    release: os.release(),
    arch: os.arch(),
    cpus: os.cpus().length + " Threads",
    totalmem: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2) + " mb",
    freemem: (os.freemem() / 1024 / 1024 / 1024).toFixed(2) + " mb",
    homedir: os.homedir(),
  };

  return JSON.stringify(infos);
}

/* 打印消息
*/
function log(message) {
  console.log(message);
}

/* 去掉字符串前后小括号
 */
function RemoveBracket(str) {
  str = str.trim();
  if (str.startsWith("(") && str.endsWith(")")) {
    return str.slice(1, -1);
  }
  return str;
}

/* 复制内容到系统剪贴板
 */
function CopyToClipboard(text) {
  const clipboard = navigator.clipboard;
  const dataTransferProviders = {
    "text/plain": text,
  };
  clipboard.write(dataTransferProviders);
}

/* 照空格分割字符串
 */
function SplitStringWithSpace(str) {
  return str.split(" ");
}

/*清理字符串中的回车符
*/
function cleanCtrlString(str) {
  return str.replace(/[\n\r]+/g, " "); // 将回车符替换为空格
}

/* RGB颜色转HSL颜色
 */
function RGBToHSV(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);

  let h,
    s,
    v = max;

  const d = max - min;
  s = max === 0 ? 0 : d / max;

  if (max === min) {
    h = 0;
  } else {
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return {
    h: parseFloat((h * 360).toFixed(0)),
    s: parseFloat((s * 100).toFixed(0)),
    v: parseFloat((v * 100).toFixed(0)),
  };
}

/* RGB颜色转HSL颜色
 */
function RGBToHSVA(r, g, b, a) {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);

  let h,
    s,
    v = max;

  const d = max - min;
  s = max === 0 ? 0 : d / max;

  if (max === min) {
    h = 0;
  } else {
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return {
    h: parseFloat((h * 360).toFixed(0)),
    s: parseFloat((s * 100).toFixed(0)),
    v: parseFloat((v * 100).toFixed(0)),
    a: a,
  };
}

/* RGB颜色转HEX
 */
function RGBToHEX(r, g, b) {
  // 确保RGB值在0到255之间
  r = Math.round(r);
  g = Math.round(g);
  b = Math.round(b);

  // 使用位运算将RGB值转换为一个整数，然后转为16进制字符串
  const hex = ((r << 16) | (g << 8) | b).toString(16);

  // 确保字符串长度为6位
  return `#${hex.padStart(6, "0")}`;
}

/* RGB颜色转0-1范围的颜色
 */
function RGBToClamp01(r, g, b) {
  let cl_r = parseFloat((r / 255).toFixed(2));
  let cl_g = parseFloat((g / 255).toFixed(2));
  let cl_b = parseFloat((b / 255).toFixed(2));

  return { r: cl_r, g: cl_g, b: cl_b };
}

/* RGB颜色转0-1范围的颜色
 */
function RGBAToClamp01(r, g, b, a) {
  let cl_r = parseFloat((r / 255).toFixed(2));
  let cl_g = parseFloat((g / 255).toFixed(2));
  let cl_b = parseFloat((b / 255).toFixed(2));
  let cl_a = parseFloat((a / 100).toFixed(2));

  return { r: cl_r, g: cl_g, b: cl_b, a: cl_a };
}

/* RGB颜色保留小数
 */
function RGBFixedNum(r, g, b, num) {
  let cl_r = parseFloat(r.toFixed(num));
  let cl_g = parseFloat(g.toFixed(num));
  let cl_b = parseFloat(b.toFixed(num));

  return { r: cl_r, g: cl_g, b: cl_b };
}

/*获取系统时间
 */
function getFormattedTime() {
  const now = new Date(); // 获取当前时间
  const hours = String(now.getHours()).padStart(2, "0"); // 获取小时并补零
  const minutes = String(now.getMinutes()).padStart(2, "0"); // 获取分钟并补零
  return `${hours}:${minutes}`; // 返回格式化的时间字符串
}

/*获取系统日期
 */
function getFormattedDate() {
  const now = new Date(); // 获取当前日期和时间

  // 获取年、月、日
  const year = now.getFullYear(); // 获取四位年份
  const month = String(now.getMonth() + 1).padStart(2, "0"); // 获取月份，+1是因为getMonth()返回的月份是从0开始的，padStart用于补零
  const day = String(now.getDate()).padStart(2, "0"); // 获取日期，padStart用于补零

  // 拼接成指定格式
  const formattedDate = `${year}/${month}/${day}`;
  return formattedDate;
}

/* 获取Json
 */
async function JsonLoad(path) {
  try {
    const data = await fs.readFile(path, "utf-8");
    const jsonData = JSON.parse(data);
    return jsonData;
  } catch (error) {
    console.error("读取或解析文件时出错:", error);
    throw error;
  }
}

//#endregion

//#region 监听事件

/* 窗口尺寸调整监听
 */
window.addEventListener("resize", () => {
  var height = body_main.clientHeight;
  layerlist.style.height = height - 180;
});

/* 窗口隐藏与显示监听
 */
document.addEventListener("uxpcommand", (event) => {
  const { commandId } = event;
  if (commandId === "uxpshowpanel") {
    uxp_show_panel();
  } else if (commandId === "uxphidepanel") {
    uxp_hide_panel();
  }
});

//#endregion

//#region 文档 & 全局操作类

/* 获取所有图层
 */
function GetAllLayers() {
  if (app.activeDocument == null) return;

  const layers = app.activeDocument.layers;

  function traverseLayers(layer) {
    AllLayers.push(layer);
    if (layer.kind === "group") {
      for (const child of layer.layers) {
        traverseLayers(child);
      }
    }
  }

  for (const layer of layers) {
    traverseLayers(layer);
  }

  return AllLayers;
}

/* 获取当前文档信息
 */
function GetDocumentInfo() {
  if (app.activeDocument == null) return null;

  //-获取文档名称
  label_doc_name.innerText = app.activeDocument.name
    .split(".")
    .slice(0, -1)
    .join(".");
  //-获取文档尺寸
  let w = app.activeDocument.width;
  let h = app.activeDocument.height;
  let size = `${w} * ${h}`;
  label_doc_size.innerText = size;
  //-获取文档分辨率
  let dpi = app.activeDocument.resolution;
  label_doc_dpi.innerText = `${dpi} dpi`;
  //-获取文档图层数
  label_doc_layers.innerText = `${AllLayers.length} 个(包含编组)`;

  label_doc_name.addEventListener("click", function () {
    CopyToClipboard(label_doc_name.innerText);
  });
  label_doc_size.addEventListener("click", function () {
    let size = label_doc_size.innerText.replace(/\s*\*\s*/, ",");
    CopyToClipboard(size);
  });
  label_doc_dpi.addEventListener("click", function () {
    CopyToClipboard(label_doc_dpi.innerText.match(/^\d+/)[0]);
  });
  label_doc_layers.addEventListener("click", function () {
    CopyToClipboard(label_doc_layers.innerText.match(/^\d+/)[0]);
  });
}

/* 清空当前文档信息
 */
function ClearDocumentInfo() {
  label_doc_name.innerText = "-";
  label_doc_size.innerText = "-";
  label_doc_dpi.innerText = "-";
  label_doc_layers.innerText = "-";
}

/* 清空获取的图层列表项和图层列表数据
 */
async function ClearItems() {
  AllLayers = [];
  layerdatas = [];
  groupdatas = [];
  while (layerlist.firstChild) {
    layerlist.removeChild(layerlist.firstChild);
  }
  layeritems = [];
}

/* 栅格化图层
 */
async function RasterizeLayer(layer) {
  await modal(async () => {
    await layer.rasterize(constants.RasterizeType.LAYERSTYLE);
  });
}

/*获取当前文档的活动模式
 */
function getFormattedDocMode(str) {
  return str.replace("ColorMode", "");
}

/* 图层添加到临时列表中
 */
async function AddListitem(layeritem) {
  if (layeritem.kind == "group" && layeritem.layers.length <= 0)
    return;

  if (!layeritem.visible)
    return;

  //#region Item_Root
  let li = document.createElement("li");
  li.id = "item_" + layeritem.id;
  li.classList.add("layerlist_item");
  //#endregion

  //#region  Item_name
  let lab_name = document.createElement("sp-label");
  lab_name.classList.add("layerlist_item_name");
  let layername = layeritem.name;
  lab_name.innerText = layername;
  li.appendChild(lab_name);
  //#endregion

  //#region  Item_size
  let lab_size = document.createElement("sp-label");
  lab_size.classList.add("layerlist_item_size");
  let layersize_w = layeritem.bounds.width;
  let layersize_h = layeritem.bounds.height;

  lab_size.innerText = `${layersize_w} * ${layersize_h}`;
  li.appendChild(lab_size);
  //#endregion

  //#region  Item_Type
  let lab_type = document.createElement("sp-picker");
  lab_type.addEventListener("change", (sd) => {
    layerdatas.forEach((item) => {
      if (item.layer_id == layeritem.id) {
        item.layer_type = SplitStringWithSpace(
          sd.target.selectedOptions[0].value
        )[0];
      }
    });
  });
  lab_type.id = "type";
  lab_type.classList.add("typepicker");
  lab_type.setAttribute("Size", "s");

  let lab_type_menu = document.createElement("sp-menu");
  lab_type_menu.setAttribute("slot", "options");

  let types = [
    ["pixel", " 图像"],
    ["text", " 文字"],
    ["shape", " 形状"],
    ["smart", " 智能"],
    ["group", " 编组"],
  ];

  for (let s = 0; s < types.length; s++) {
    let lab_type_menu_item = document.createElement("sp-menu-item");
    lab_type_menu_item.classList.add("typeitem");
    lab_type_menu_item.innerText = types[s][0];

    let lab_type_menu_item_des = document.createElement("span");
    lab_type_menu_item_des.classList.add("typeitem_description");
    lab_type_menu_item_des.innerText = types[s][1];
    if (layeritem.kind == "text") {
      if (s == 1) lab_type_menu_item.setAttribute("selected");
    } else if (layeritem.kind == "pixel") {
      if (s == 0) lab_type_menu_item.setAttribute("selected");
    } else if (layeritem.kind == "group") {
      if (s == 4) lab_type_menu_item.setAttribute("selected");
    } else if (layeritem.kind == "solidColor") {
      if (s == 2) lab_type_menu_item.setAttribute("selected");
    } else if (layeritem.kind == "smartObject") {
      if (s == 3) lab_type_menu_item.setAttribute("selected");
    }
    lab_type_menu_item.appendChild(lab_type_menu_item_des);
    lab_type_menu.appendChild(lab_type_menu_item);
  }

  let lab_type_menu_divider = document.createElement("sp-menu-divider");
  lab_type_menu.appendChild(lab_type_menu_divider);
  let lab_type_menu_item_none = document.createElement("sp-menu-item");
  lab_type_menu_item_none.innerText = "未知";
  lab_type_menu.appendChild(lab_type_menu_item_none);
  lab_type.appendChild(lab_type_menu);
  li.appendChild(lab_type);
  //#endregion

  //#region HasMask
  let hasMask = await action.batchPlay(
    [
      {
        "_obj": "get",
        "_target": [
          {
            "_property": "hasUserMask"
          },
          {
            "_ref": "layer",
            "_name": layeritem.name
          },
        ],
      }
    ], {
    "synchronousExecution": false,
    "modalBehavior": "execute"
  });
  //#endregion

  //#region DataStored

  //#region DS-Text
  let content = "";
  let textcolor = { r: 0, g: 0, b: 0 };
  let textsize = 0;
  let fontname = "";
  let fontfamily = "";
  let fontstyle = "";
  let font_alignment = "";
  let font_space = 0;
  let isWrapText = false;
  let isuppercase = false;
  let textleading = 0;

  if (layeritem.kind == "text") {
    content = layeritem.kind == "text" ? layeritem.textItem.contents : "";
    textcolor = RGBFixedNum(
      layeritem.textItem.characterStyle.color.rgb.red,
      layeritem.textItem.characterStyle.color.rgb.green,
      layeritem.textItem.characterStyle.color.rgb.blue,
      2
    );
    const font_scr_name = require('photoshop').app.fonts.getByName(layeritem.textItem.characterStyle.font);

    fontname = font_scr_name.name;
    fontfamily = font_scr_name.family;
    fontstyle = font_scr_name.style;

    let justification = layeritem.textItem.paragraphStyle.justification;

    if (!justification || justification.trim() === "") {
      justification = "left";
    }
    font_alignment = justification;

    isWrapText = layeritem.textItem.isParagraphText;

    let cap = layeritem.textItem.characterStyle.capitalization;
    if (cap == "allCaps")
      isuppercase = true;

    let leadstate = layeritem.textItem.characterStyle.useAutoLeading;

    if (leadstate)
      textleading = 0;
    else
      textleading = layeritem.textItem.characterStyle.leading;

    font_space = layeritem.textItem.characterStyle.tracking;

    var info = action.batchPlay(
      [
        {
          _obj: "get",
          _target: [{ _ref: "layer", _id: layeritem.id }],
          _options: {
            dialogOptions: "dontDisplay",
          },
        },
      ],
      {
        synchronousExecution: true,
        modalBehavior: "execute",
      }
    );
    textsize = Number(
      info[0].textKey.textStyleRange[0].textStyle.impliedFontSize._value
    );
  }
  //#endregion

  //#region DS-类型判定
  let kind = "";
  if (layeritem.kind == "solidColor") kind = "shp";
  else if (layeritem.kind == "smartObject") kind = "smt";
  else if (layeritem.kind == "text") kind = "txt";
  else if (layeritem.kind == "pixel") kind = "pix";
  else kind = layeritem.kind;
  //#endregion

  //#region DS-父级物体名称
  let parentName = "";
  let parentid = 0;
  if (layeritem.parent != null) {
    parentName = layeritem.parent.name;
    parentid = layeritem.parent.id;
  } else {
    parentName = "none";
  }
  //#endregion

  //#region DS-边距
  let anchorposition = {
    x: layeritem.bounds.left,
    y: layeritem.bounds.top,
    x_bypass: layeritem.boundsNoEffects.left,
    y_bypass: layeritem.boundsNoEffects.top,
  };
  //#endregion

  //#region DS-形状颜色
  let LayerColor = { r: 0, g: 0, b: 0 };
  if (layeritem.kind == "solidColor") {
    LayerColor = {
      r: parseFloat(
        layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.hasOwnProperty(
          "red"
        )
          ? layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.red.toFixed(
            2
          )
          : layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.redFloat.toFixed(
            2
          )
      ),
      g: parseFloat(
        layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.hasOwnProperty(
          "grain"
        )
          ? layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.grain.toFixed(
            2
          )
          : layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.greenFloat.toFixed(
            2
          )
      ),
      b: parseFloat(
        layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.hasOwnProperty(
          "blue"
        )
          ? layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.blue.toFixed(
            2
          )
          : layeritem.adjustmentInfo.solidColor[0].adjustment[0].color.blueFloat.toFixed(
            2
          )
      ),
    };
  }
  //#endregion

  //#region DS-图层路径
  let namekind = "";
  if (layeritem.kind == "solidColor") namekind = "shp";
  if (layeritem.kind == "smartObject") namekind = "smt";
  if (layeritem.kind == "pixel") namekind = "pix";
  if (layeritem.kind == "text") namekind = "txt";

  let layerpath = "";
  if (layeritem.kind != "group")
    layerpath =
      String(app.activeDocument.path).replace(app.activeDocument.name, "") +
      "Sprites\\" +
      layeritem.id +
      "_" +
      namekind +
      "_" +
      layername +
      ".png";
  else layerpath = "none";
  //#endregion

  //#region DS-图层信息赋值
  let info_layer = {
    path: layerpath,
    id: layeritem.id,
    name: layername,
    type: kind,
    mask: hasMask[0].hasUserMask,
    size: {
      width: layersize_w,
      height: layersize_h,
    },
    position: anchorposition,
    parent: { name: parentName, id: parentid },
    opacity: layeritem.opacity,
    color_rgb: LayerColor,
    color_rgba: {
      r: LayerColor.r,
      g: LayerColor.g,
      b: LayerColor.b,
      a: (layeritem.opacity / 100) * 255,
    },
    color_hsv: RGBToHSV(LayerColor.r, LayerColor.g, LayerColor.b),
    color_hsva: RGBToHSVA(
      LayerColor.r,
      LayerColor.g,
      LayerColor.b,
      layeritem.opacity
    ),
    color_clamp_rgb: RGBToClamp01(LayerColor.r, LayerColor.g, LayerColor.b),
    color_clamp_rgba: RGBAToClamp01(
      LayerColor.r,
      LayerColor.g,
      LayerColor.b,
      layeritem.opacity
    ),
    color_hex: RGBToHEX(LayerColor.r, LayerColor.g, LayerColor.b),
    text: content,
    ft_name: fontname,
    ft_family: fontfamily,
    ft_style: fontstyle,
    ft_size: textsize,
    ft_align: font_alignment,
    ft_space: font_space,
    ft_isWrapText: isWrapText,
    ft_isuppercase: isuppercase,
    ft_leading: textleading,
    ft_color_rgb: textcolor,
    ft_color_rgba: {
      r: textcolor.r,
      g: textcolor.g,
      b: textcolor.b,
      a: (layeritem.opacity / 100) * 255,
    },
    ft_color_hsv: RGBToHSV(textcolor.r, textcolor.g, textcolor.b),
    ft_color_hsva: RGBToHSVA(
      textcolor.r,
      textcolor.g,
      textcolor.b,
      layeritem.opacity
    ),
    ft_color_clamp_rgb: RGBToClamp01(textcolor.r, textcolor.g, textcolor.b),
    ft_color_clamp_rgba: RGBAToClamp01(
      textcolor.r,
      textcolor.g,
      textcolor.b,
      layeritem.opacity
    ),
    ft_color_hex: RGBToHEX(textcolor.r, textcolor.g, textcolor.b),
  };
  //#endregion

  //#region DS-编组计数
  let count_gp = 0;
  if (layeritem.kind == "group") {
    count_gp = layeritem.layers.length;
  }
  //#endregion

  //#region DS-编组信息赋值
  let info_group = {
    name: layername,
    id: layeritem.id,
    parent: { name: parentName, id: parentid },
    childs: count_gp,
  };
  //#endregion

  //#region DS-推送数据到数组
  if (layeritem.kind == "group")
    groupdatas.push(info_group);

  layerdatas.push(info_layer);

  //#endregion

  //#endregion

  layerlist.appendChild(li);
}

//#endregion

//#region 图层操作

/* 导出json数据
 */
async function ExportJson(data) {
  let json = JSON.stringify(data, (key, value) => {
    if (typeof value === "string") {
      return value.replace(/[\n\r]+/g, ""); // 将回车符替换为空格
    }
    return value;
  });
  const file = await storage.localFileSystem.getFileForSaving(
    "LayerDatas.json"
  );
  await file.write(json);

  exportLayers(AllLayers);
}

async function selectLayers(...layers) {
  const target = layers.map((layer) => {
    if (layer.kind === "group") return null;
    return { _ref: "layer", _id: layer._id };
  });
  await core.executeAsModal(async () => {
    await action.batchPlay(
      [
        {
          _obj: "select",
          makeVisible: false,
          _target: target.filter((v) => !!v),
          _options: { dialogOptions: "dontDisplay" },
        },
      ],
      { synchronousExecution: true }
    );
  });
}

async function exportActiveLayer(output, options) {
  await core.executeAsModal(async () => {
    await action.batchPlay(
      [
        Object.assign(
          {
            sRGB: true,
            quality: 32,
            metadata: 0,
            fileType: "png",
            openWindow: false,
            destFolder: decodeURIComponent(output),
            _obj: "exportSelectionAsFileTypePressed",
            _options: { dialogOptions: "dontDisplay" },
            _target: [
              { _ref: "layer", _enum: "ordinal", _value: "targetEnum" },
            ],
          },
          options || {}
        ),
      ],
      { synchronousExecution: true }
    );
  });
}

async function exportLayers(layers) {
  const outputDir =
    String(app.activeDocument.path).replace(app.activeDocument.name, "") +
    "Sprites";

  await core.executeAsModal(() => {
    for (const layer of layers) {
      if (!layer.locked) {
        if (!layer.originalName) {
          layer.originalName = layer.name;
        }
        if (layer.name === layer.originalName) {
          let kind = "";
          if (layer.kind == "solidColor") kind = "shp";
          if (layer.kind == "smartObject") kind = "smt";
          if (layer.kind == "pixel") kind = "pix";
          if (layer.kind == "text") kind = "txt";
          layer.name = `${layer._id}_${kind}_${layer.name}`;
        }
      }
    }
  });

  await core.executeAsModal(async () => {
    await selectLayers(...layers);
    await exportActiveLayer(outputDir);
  });

  setTimeout(async () => {
    await core.executeAsModal(() => {
      for (const layer of layers) {
        if (layer.originalName) {
          layer.name = layer.originalName;
        }
      }
    });
    // 假设十张图片需要 200 的等待时间
    // }, Math.ceil(layers.length / 10) * 200);
    // 1 秒适用大部分文件
  }, 1000);

  // await openDialog_status("文档图层结构数据导出完成！请等待批处理阶段工作完成！如果强制关闭 PS 则会导致导出的图层文件缺失！", "明白");
}

//#endregion

//#region 面板显示 & 隐藏

/* 面板显示
 */
function uxp_show_panel() { }

/* 面板隐藏
 */
function uxp_hide_panel() {
  ClearItems();
  ClearDocumentInfo();
  export_json_btn.style.display = "none";
  clear_btn.style.display = "none";
}

//#endregion

//#region 对话框

/* 帮助对话框
 */
const openDialog = async () => {
  const res = await document.querySelector("#dialog").uxpShowModal({
    title: "XHUD Fusion 帮助",
    resize: "none",
    size: {
      width: 464,
      height: 200,
    },
  });
  if (res == "tutorial") {
    const { shell } = require("uxp");
    shell.openExternal("http://sevenstrike.com/col.jsp?id=105");
    // console.log("tutorial")
  }
};

/**状态告知对话框
 * @param {string} msg - 消息内容
 * @param {string} statu - 按钮文字
 */
const openDialog_status = async (msg, statu) => {
  document.querySelector("#dialog_status").querySelector("#text").innerText =
    msg;
  document.querySelector("#dialog_status").querySelector("#btntxt").innerText =
    statu;

  const res = await document.querySelector("#dialog_status").uxpShowModal({
    title: "XHUD Fusion 状态",
    resize: "none",
    size: {
      width: 464,
      height: 200,
    },
  });
  // console.log(`${res}`)
};

//#endregion
